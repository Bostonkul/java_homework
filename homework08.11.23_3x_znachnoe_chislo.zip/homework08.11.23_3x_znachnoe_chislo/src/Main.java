import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Вывести на экран все цифры этого числа
        //

        Scanner scr = new Scanner(System.in);
        int number = scr.nextInt();
        String string_number = Integer.toString(number);
        System.out.print("число " + number + " -> ");
        for (int i = 0; i < string_number.length(); i++) {
            System.out.print(string_number.charAt(i) + ", ");
        }
    }
}