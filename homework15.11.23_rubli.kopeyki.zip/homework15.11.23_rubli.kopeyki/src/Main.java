import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Пользователь-продавец вводит суммарную стоимость покупок
        // и сумму денег, которую дал покупатель. Выведите сумму сдачи
        // в виде “X рублей и Y копеек”.

                Scanner scr = new Scanner(System.in);
                System.out.print("Введите стоимость покупок: ");
                double cost = scr.nextDouble();
                System.out.print("Введите сумму денег, которую дал покупатель: ");
                double payment = scr.nextDouble();
                double change = payment - cost;
                int rubles = (int) change;
                int kopeks = (int) Math.round((change - rubles) * 100);
                System.out.printf("Сумма сдачи: %d рублей и %d копеек", rubles, kopeks);
            }
        }