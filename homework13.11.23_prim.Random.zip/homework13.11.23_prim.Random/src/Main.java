import java.util.Random;

public class Main {
            public static void main(String[] args) {
                //Напишите программу, в которой объявите переменные всех примитивных типов.
                //Значение для каждой переменной сгенерируйте с помощью класса Random.
                // При необходимости используйте приведение типов. Полученные значения выведите в консоль.
                //2 В этой же программе создайте переменную типа String. Сгенерируйте значение для строки.
                // При необходимости используйте метод String.valueOf(). Ограничений на длину строки и содержимое нет.
                // Полученное значение выведите в консоль.
                Random random = new Random();
                int i = random.nextInt();
                byte b = (byte) random.nextInt();
                short s = (short) random.nextInt();
                long l = random.nextLong();
                float f = random.nextFloat();
                double d = random.nextDouble();
                boolean bool = random.nextBoolean();

                System.out.println("int: " + i);
                System.out.println("byte: " + b);
                System.out.println("short: " + s);
                System.out.println("long: " + l);
                System.out.println("float: " + f);
                System.out.println("double: " + d);
                System.out.println("boolean: " + bool);

                String str = String.valueOf(random.nextInt());
                System.out.println("string: " + str);
            }
        }