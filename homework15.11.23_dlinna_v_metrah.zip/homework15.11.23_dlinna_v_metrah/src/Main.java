import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //1 Дана длина в метрах. Напишите программу,
        // которая переводит указанное значение в км, мили, футы и аршины.
        // Выведите начальное и конвертированные значения на экран.

        Scanner input = new Scanner(System.in);
        System.out.print("Введите длину в метрах: ");
        double meters = input.nextDouble();

        double kilometers = meters / 1000;
        double miles = meters / 1609.344;
        double feet = meters * 3.28084;
        double arshins = meters / 0.7112;

        System.out.println(meters + " метров = " + kilometers + " километров");
        System.out.println(meters + " метров = " + miles + " миль");
        System.out.println(meters + " метров = " + feet + " футов");
        System.out.println(meters + " метров = " + arshins + " аршинов");
    }
}