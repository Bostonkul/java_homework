public class Main {
    public static void main(String[] args) {

        System.out.println("моя фамилия Bostonkulova");
        System.out.println("");
        System.out.print("моя фамилия Bostonkulova");
        System.out.println("моя фамилия Bostonkulova");
        System.out.printf("моя фамилия %s", "Bostonkulova");
    }
}