public class Main {
    public static void main(String[] args) {
        System.out.println("33");
        System.out.printf("мне %s полных лет", 33);
    }
}